export interface ClienteI {
    name: string;
    city: string;
    order: string;
    id:any;
  }