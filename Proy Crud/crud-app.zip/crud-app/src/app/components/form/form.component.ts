import { Component, OnInit } from '@angular/core';


//Llamar al servicio
import {ClientesService} from '../../services/clientes.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  constructor(public cliente: ClientesService) { }

  ngOnInit(): void {
  }

  onSave(){
    this.cliente.editClientes
  }

}
