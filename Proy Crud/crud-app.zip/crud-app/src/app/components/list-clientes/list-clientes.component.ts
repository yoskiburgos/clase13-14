import { Component, OnInit, ViewChild } from '@angular/core';

import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {ClienteI} from '../../models/cliente.interface';

//Importar servicio
import { ClientesService } from '../../services/clientes.service'


@Component({
  selector: 'app-list-clientes',
  templateUrl: './list-clientes.component.html',
  styleUrls: ['./list-clientes.component.css']
})
export class ListClientesComponent implements OnInit {

  displayedColumns: string[] = [ 'name', 'city', 'order', 'actions'];
  dataSource = new MatTableDataSource();

  //Inyectar el servicio
  constructor(private clientesService: ClientesService){ }
 
  ngOnInit() {
    //Utilizar el servicio
    this.clientesService.getAllClientes().subscribe(res =>  this.dataSource.data = res);
   // this.dataSource.sort = this.sort;
  }

  //Despues de Iniciado Angular
  ngAfterViewInit(){
    this.dataSource.sort = this.sort;
  }

 // @ViewChild(MatSort, {static: true}) sort: MatSort;
 @ViewChild(MatSort) sort: MatSort;


 onEdit(element){
    this.clientesService.selected = element;
 }

 onDelete(id:string){
  this.clientesService.eliminaClientes(id);
 }

}
