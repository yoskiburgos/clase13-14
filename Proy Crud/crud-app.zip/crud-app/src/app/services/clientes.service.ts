import { Injectable } from '@angular/core';

import {AngularFirestore, AngularFirestoreCollection} from '@angular/fire/firestore';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {ClienteI} from '../models/cliente.interface';

export interface ClienteID extends ClienteI {id:string;}

@Injectable({
  providedIn: 'root'
})
export class ClientesService {
  private clienteCollection : AngularFirestoreCollection<ClienteI>;
  clientes: Observable<ClienteI[]>;

  public selected = {
    id:null,
    name:'',
    city:'',
    order:''
  }


  constructor(private readonly afs: AngularFirestore) { 
    this.clienteCollection = afs.collection<ClienteI>('clientes');
    this.clientes = this.clienteCollection.snapshotChanges().pipe(
      map( actions => actions.map(a =>{
        const data = a.payload.doc.data() as ClienteI;
        const id = a.payload.doc.id;
        return {id, ...data}
      }))
    );

  }

  getAllClientes(){
    return this.clientes;
  }

  editClientes(cliente: ClienteI){
    let id = cliente.id;
    return this.clienteCollection.doc(id).update(cliente);
  }

  eliminaClientes(id: string){
    return this.clienteCollection.doc(id).delete();
  }


}
